#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
projectmap.py -- laver PROJECT_MAP.md: et kort over projektet, som kan indsættes i en AI-samtale i stedet for at sende filerne.

    python projectmap.py                       skriver PROJECT_MAP.md i projektmappen
    python projectmap.py --stdout              udskriver i stedet for at skrive en fil
    python projectmap.py --ignorer _arkiv,tools   springer mapper (eller filer) over
    python projectmap.py --scraper             kun det, du skal bruge til at tilføje en butik (skriver PROJECT_MAP_scraper.md)
    python projectmap.py --kort                uden nøglelister og referencer (skriver PROJECT_MAP_kort.md)

Noterne øverst (formål, pipeline, "sådan tilføjer du en butik" ...) hentes fra PROJECT_NOTER.md ved siden af scriptet.
Med --scraper medtages kun de noter, der begynder med "- [S] "; mærket fjernes i udskriften.
Resten udledes af koden, så kortet kan aldrig komme ud af trit med projektet. Redigér ikke PROJECT_MAP.md i hånden.

Rører ingenting i projektet: læser kun filerne. Skjuler værdier, der ligner nøgler, tokens og adgangskoder.
"""
import ast
import warnings
import collections
import datetime
import os
import re
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = {".git", "venv", ".venv", "env", "__pycache__", "node_modules", ".idea", ".vscode", ".mypy_cache", ".pytest_cache"}
# projectmap-version: 6
OUT = "PROJECT_MAP.md"
NOTES = "PROJECT_NOTER.md"
NOTES_ALT = "PROJECT_NOTES.md"         # BeerSniffers navn; bruges, hvis PROJECT_NOTER.md ikke findes
IGNORE_FILE = ".projectmapignore"      # én mappe eller fil pr. linje; bruges ud over --ignorer
COLLAPSE_OVER = 25          # mapper med flere undermapper end dette vises som "mappe/*"
DATA_EXT = r"json|xlsx|xml|html|csv|txt|md|bat|ps1|db|sqlite|css|js"
STDLIB = set(getattr(sys, "stdlib_module_names", ())) | {"__future__"}
SECRET_NAME = re.compile(r"(KEY|TOKEN|SECRET|PASS|PWD|AUTH|CREDENTIAL|PRIVATE)", re.I)

args = sys.argv[1:]
STDOUT = "--stdout" in args
SCRAPER_MODE = "--scraper" in args
KORT = "--kort" in args or SCRAPER_MODE
if SCRAPER_MODE:
    OUT = "PROJECT_MAP_scraper.md"
elif KORT:
    OUT = "PROJECT_MAP_kort.md"
IGNORE = []
for i, a in enumerate(args):
    if a == "--ignorer" and i + 1 < len(args):
        IGNORE = [x.strip().strip("/\\") for x in args[i + 1].split(",") if x.strip()]


try:
    with open(os.path.join(ROOT, IGNORE_FILE), encoding="utf-8-sig") as _fh:
        IGNORE += [x.strip().strip("/\\") for x in _fh.read().splitlines() if x.strip() and not x.strip().startswith("#")]
except OSError:
    pass


def ignored(rel):
    return any(rel == p or rel.startswith(p + "/") for p in IGNORE)


# ───────────────────────── find filer ─────────────────────────
files, dirs = [], set()
for dp, dn, fn in os.walk(ROOT):
    dn[:] = sorted(d for d in dn if d not in SKIP_DIRS)
    rel_dir = os.path.relpath(dp, ROOT).replace("\\", "/")
    rel_dir = "" if rel_dir == "." else rel_dir
    if ignored(rel_dir) and rel_dir:
        dn[:] = []
        continue
    if rel_dir:
        dirs.add(rel_dir)
    for f in sorted(fn):
        rel = (rel_dir + "/" + f) if rel_dir else f
        if not ignored(rel):
            files.append(rel)

py_files = sorted(f for f in files if f.endswith(".py"))
other_files = [f for f in files if not f.endswith(".py")]
py_set = set(py_files)


def read(rel):
    try:
        with open(os.path.join(ROOT, rel), encoding="utf-8-sig", errors="replace") as fh:
            return fh.read().replace("\r\n", "\n")
    except OSError:
        return ""


# ───────────────────────── analyse af en .py-fil ─────────────────────────
def short(s, n=60):
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[: n - 1] + "…"


def const_text(name, node):
    """NAVN=værdi (kun enkle værdier; hemmeligheder skjules)."""
    try:
        txt = ast.unparse(node)
    except Exception:
        return name
    if SECRET_NAME.search(name):
        return f"{name}=<skjult>"
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        v = node.value
        if len(v) > 60:
            return name
        if re.fullmatch(r"[A-Za-z0-9_\-]{20,}", v) and re.search(r"\d", v) and re.search(r"[A-Za-z]", v):
            return f"{name}=<skjult>"
        if "://" in v and "@" in v.split("://", 1)[1].split("/", 1)[0]:
            return f"{name}=<skjult>"
    simple = isinstance(node, ast.Constant) or (isinstance(node, (ast.Dict, ast.List, ast.Tuple)) and len(txt) <= 70) \
        or (isinstance(node, ast.BinOp) and len(txt) <= 50) or (isinstance(node, ast.Call) and len(txt) <= 55 and "(" in txt)
    return f"{name}={short(txt, 70)}" if simple else name


def resolve_local(mod, names=()):
    """Find projektfiler, som et import peger på."""
    out = set()
    base = mod.replace(".", "/") if mod else ""
    for cand in (base + ".py", base + "/__init__.py"):
        if base and cand in py_set:
            out.add(cand)
    for n in names:
        cand = (base + "/" + n + ".py") if base else (n + ".py")
        if cand in py_set:
            out.add(cand)
    return out


def analyse(rel):
    src = read(rel)
    info = {"path": rel, "lines": src.count("\n") + 1 if src else 0, "src": src, "error": None}
    try:
        with warnings.catch_warnings(record=True) as wrec:
            warnings.simplefilter("always")
            tree = ast.parse(src)
        info["warns"] = [(w.lineno, str(w.message)) for w in wrec if issubclass(w.category, (SyntaxWarning, DeprecationWarning))]
    except SyntaxError as e:
        info["error"] = e.lineno or 1
        return info
    info["doc"] = (ast.get_docstring(tree) or "").strip().split("\n")[0][:120]
    imports, ext = set(), set()
    consts, funcs, classes, routes = [], [], [], []
    has_main, toplevel_code = False, False
    env = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            for a in node.names:
                loc = resolve_local(a.name)
                imports |= loc
                if not loc:
                    ext.add(a.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.level:                                   # relative import
                pkg = os.path.dirname(rel).replace("\\", "/")
                mod = (pkg + "/" + (node.module or "").replace(".", "/")).strip("/")
                loc = resolve_local(mod.replace("/", "."), [a.name for a in node.names])
            else:
                loc = resolve_local(node.module or "", [a.name for a in node.names])
            imports |= loc
            if not loc and not node.level and node.module:
                ext.add(node.module.split(".")[0])
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = node.args
            names = [x.arg for x in a.posonlyargs + a.args] + (["*" + a.vararg.arg] if a.vararg else []) \
                + [x.arg for x in a.kwonlyargs] + (["**" + a.kwarg.arg] if a.kwarg else [])
            funcs.append((node.name, ", ".join(names), node.lineno))
            for d in node.decorator_list:
                if isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) and d.func.attr in ("get", "post", "put", "delete", "route", "patch") \
                        and d.args and isinstance(d.args[0], ast.Constant):
                    routes.append((d.func.attr.upper(), str(d.args[0].value), node.name))
        elif isinstance(node, ast.ClassDef):
            bases = ", ".join(ast.unparse(b) for b in node.bases)
            classes.append((node.name, bases, node.lineno))
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            tgts = node.targets if isinstance(node, ast.Assign) else [node.target]
            for t in tgts:
                if isinstance(t, ast.Name) and re.fullmatch(r"_?[A-Z][A-Z0-9_]*", t.id) and node.value is not None:
                    consts.append(const_text(t.id, node.value))
        elif isinstance(node, ast.If):
            if "__main__" in ast.unparse(node.test):
                has_main = True
        elif isinstance(node, ast.Expr):
            if not (isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)):
                toplevel_code = True
        elif isinstance(node, (ast.For, ast.While, ast.With)):
            toplevel_code = True
    built, read_k, refs = set(), set(), set()
    const_dicts = set()                               # ordbøger i konstanter (fx SHOP_SHIPPING) er ikke varer
    for node in tree.body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)) and node.value is not None:
            tg = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(x, ast.Name) and re.fullmatch(r"_?[A-Z][A-Z0-9_]*", x.id) for x in tg):
                const_dicts |= {id(d) for d in ast.walk(node.value) if isinstance(d, ast.Dict)}
    for n in ast.walk(tree):
        if isinstance(n, ast.Dict) and id(n) in const_dicts:
            continue
        if isinstance(n, ast.Dict):
            for k in n.keys:
                if isinstance(k, ast.Constant) and isinstance(k.value, str):
                    built.add(k.value)
        elif isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant) and isinstance(n.slice.value, str):
            (built if isinstance(n.ctx, ast.Store) else read_k).add(n.slice.value)
        elif isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("get", "pop", "setdefault") \
                and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str) \
                and ast.unparse(n.func.value) not in ("os.environ", "environ"):
            read_k.add(n.args[0].value)
        if isinstance(n, ast.Call):
            f = ast.unparse(n.func)
            if f in ("os.environ.get", "os.getenv", "environ.get", "getenv") and n.args and isinstance(n.args[0], ast.Constant):
                env.add(str(n.args[0].value))
        if isinstance(n, ast.Subscript) and ast.unparse(n.value) == "os.environ" and isinstance(n.slice, ast.Constant):
            env.add(str(n.slice.value))
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and len(n.value) < 120 and "://" not in n.value:
            if re.fullmatch(r"[\w./\\{}\- ]*[\w}]\.(?:%s)" % DATA_EXT, n.value):
                refs.add(n.value.replace("\\", "/").split("/")[-1])

    def clean(keys):
        return {k for k in keys if 0 < len(k) <= 32 and "\n" not in k}
    info.update(imports=imports, ext=ext, consts=consts, funcs=funcs, classes=classes, routes=routes, has_main=has_main,
                toplevel_code=toplevel_code, built=clean(built), read=clean(read_k), refs=refs, env=env)
    return info


infos = {f: analyse(f) for f in py_files}
local_tops = {f.split("/")[0].replace(".py", "") for f in py_files}
for i in infos.values():                                  # eksterne pakker: fjern standardbibliotek og projektets egne moduler
    if "ext" in i:
        i["ext"] = {e for e in i["ext"] if e not in STDLIB and e not in local_tops}
used_by = collections.defaultdict(set)
for f, i in infos.items():
    for dep in i.get("imports", ()):
        if dep != f:
            used_by[dep].add(f)

# start-scripts (.bat/.ps1): hvilke .py-filer de starter
scripts = [f for f in other_files if re.search(r"\.(bat|ps1)$", f) and f.count("/") <= 1]
started_by = collections.defaultdict(set)
script_text = {s: read(s) for s in scripts}
for s, txt in script_text.items():
    for m in re.finditer(r"([\w./\\-]+\.py)\b", txt):
        started_by[m.group(1).replace("\\", "/")].add(s)

# ───────────────────────── fælles nøglesæt ─────────────────────────
set_files = collections.defaultdict(list)
for f, i in infos.items():
    if len(i.get("built", ())) >= 8:
        set_files[frozenset(i["built"])].append(f)
shared = [(k, v) for k, v in set_files.items() if len(v) >= 3]
shared.sort(key=lambda kv: -len(kv[1]))
shared_name = {k: f"K{n}" for n, (k, v) in enumerate(shared, 1)}


def key_text(keys, built_set=None):
    if built_set is not None and not KORT and frozenset(built_set) in shared_name:
        return shared_name[frozenset(built_set)]
    ks = sorted(keys, key=lambda x: (x.lower(), x))
    return ", ".join(ks[:40]) + (" …" if len(ks) > 40 else "")


# ───────────────────────── skriv kortet ─────────────────────────
L = []
add = L.append
project = os.path.basename(ROOT)
add(f"# PROJECT_MAP - {project}")
add("")
add(f"_Genereret {datetime.datetime.now().strftime('%d-%m-%Y %H:%M')} af projectmap.py. Redigér ikke manuelt; kør scriptet igen._")
add("")
add("## Noter")
notes_path = None
for cand in (os.path.join(ROOT, NOTES), os.path.join(ROOT, NOTES_ALT), os.path.join(os.path.dirname(os.path.abspath(__file__)), NOTES)):
    if os.path.isfile(cand):
        notes_path = cand
        break
if notes_path:
    with open(notes_path, encoding="utf-8-sig", errors="replace") as fh:
        _all_lines = fh.read().replace("\r\n", "\n").strip().split("\n")
        _has_tags = any(l.startswith("- [S] ") for l in _all_lines)
        for line in _all_lines:
            line = line.rstrip()
            tagged = line.startswith("- [S] ") or (SCRAPER_MODE and not _has_tags)   # ingen [S] i filen: tag alle noter med
            if line.startswith("- [S] "):
                line = "- " + line[6:]
            if SCRAPER_MODE and not tagged:
                continue                                  # --scraper: kun noter mærket [S]
            add(line)
else:
    add(f"- (Ingen {NOTES} fundet. Læg en fil med dette navn ved siden af scriptet, så kommer dine noter her.)")
add("")

entry = sorted(f for f, i in infos.items() if i.get("has_main"))
total_lines = sum(i["lines"] for i in infos.values())
add("## Overblik")
add(f"- {len(py_files)} Python-filer ({total_lines} linjer), {len(other_files)} andre filer")
if entry and not SCRAPER_MODE:
    add("- Entry points (`__main__`): " + ", ".join(f"`{e}`" for e in entry))
sc = sorted(p for p in started_by if p in py_set)
if sc and not SCRAPER_MODE:
    add("- Startes fra script/config: " + ", ".join(f"`{p}`" for p in sc))
nroutes = sum(len(i.get("routes", ())) for i in infos.values())
if nroutes:
    add(f"- {nroutes} routes")
envs = sorted({e for i in infos.values() for e in i.get("env", ())})
if envs:
    add("- Miljøvariabler: " + ", ".join(f"`{e}`" for e in envs))
allext = sorted({e for i in infos.values() for e in i.get("ext", ())})
if allext:
    add("- Eksterne pakker: " + ", ".join(allext))
add("")

def ext_of(f):
    e = os.path.splitext(f)[1]
    return e if e else "(ingen)"


def ext_counts(fl):
    c = collections.Counter(ext_of(f) for f in fl)
    return ", ".join(f"{n} {e}" for e, n in sorted(c.items(), key=lambda kv: (-kv[1], kv[0])))


all_files = files
by_dir = collections.defaultdict(list)
for f in all_files:
    by_dir[os.path.dirname(f)].append(f)
sub_count = collections.Counter()
for d in dirs:
    sub_count[os.path.dirname(d)] += 1
collapsed = {d for d in dirs if sub_count[d] > COLLAPSE_OVER}
if not SCRAPER_MODE:
    add("## Mapper (max dybde 3)")
    add(f"- `./` - {ext_counts(by_dir['']) or '(tom)'}")
    for d in sorted(dirs):
        if d.count("/") >= 3 or any(d == c or d.startswith(c + "/") for c in collapsed if c != d):
            continue
        if d in collapsed:
            fl = [f for f in all_files if f.startswith(d + "/")]
            add(f"- `{d}/*` - {sub_count[d]} mapper, {ext_counts(fl)}")
        elif by_dir.get(d):
            add(f"- `{d}/` - {ext_counts(by_dir[d])}")
    add("")

if shared and not KORT:
    add("## Fælles nøglesæt")
    for k, v in shared:
        add(f"- {shared_name[k]} ({len(v)} filer): " + ", ".join(sorted(k, key=lambda x: (x.lower(), x))))
    add("")

# butikker, der findes automatisk (fx shops.py, som læser app/scrapers med importlib)
auto_by = sorted(f for f, i in infos.items() if i.get("src") and "importlib" in i["src"] and "scraper" in i["src"].lower()
                 and os.path.basename(f) not in ("projectmap.py", "tjek_scraper_kort.py"))
auto_note = ("auto-fundet via " + ", ".join(f"`{a}`" for a in auto_by[:2])) if auto_by else None

# scrapere
scrapers = []
for f, i in infos.items():
    sf = [(n, a, ln) for n, a, ln in i.get("funcs", ()) if n == "scrape" or n.startswith("scrape_")]
    if sf:
        scrapers.append((f, i, sf))
if scrapers:
    add("## Scrapere (til nye butikker)")
    add("Hver linje: fil · scraper-funktion · platform (gættet ud fra koden) · butiks-konstanter · hvor den er koblet på · nøgler den bygger.")
    for f, i, sf in scrapers:
        own = i["src"].lower()
        helper_src = {h: infos[h]["src"].lower() for h in i.get("imports", ()) if h in infos}
        plat = []

        def has(word):
            if word in own:
                return ""
            hit = next((h for h, hs in helper_src.items() if word in hs), None)
            return None if hit is None else f" via `{hit}`"
        for label, words in (("Shopify (products.json)", ("products.json",)), ("WooCommerce Store API", ("wc/store", "wp-json/wc")),
                             ("XML-feed", ("google.com/ns/1.0",)), ("GraphQL", ("graphql",)), ("HTML (BeautifulSoup)", ("bs4", "beautifulsoup")),
                             ("Selenium", ("selenium",)), ("cloudscraper", ("cloudscraper",))):
            for w in words:
                r = has(w)
                if r is not None:
                    plat.append(label + r); break
        if not plat and has("wp-json") is not None:
            plat.append("WordPress/Woo API" + has("wp-json"))
        shop = [c for c in i["consts"] if re.match(r"SHOP_(NAME|URL|SHIPPING)\b", c)]
        wired = []
        for g in sorted(used_by.get(f, ())):
            lines = infos[g]["src"].split("\n")
            imp = next((n for n, l in enumerate(lines, 1) if re.match(r"\s*(from|import)\s", l) and os.path.splitext(os.path.basename(f))[0] in l), None)
            call = [n for n, l in enumerate(lines, 1) if any(re.search(r"\b%s\(" % re.escape(fn), l) for fn, _, _ in sf) and not l.lstrip().startswith(("def ", "from ", "import "))]
            part = f"`{g}`" + (f" (import L{imp}" if imp else " (")
            part += (f", kald L{', L'.join(map(str, call[:3]))}" if call else "") + ")"
            wired.append(part.replace("( ", "(").replace("(, ", "("))
        bits = [f"`{f}`", " / ".join(f"`{n}({a})` L{ln}" for n, a, ln in sf), "platform: " + (" + ".join(plat) if plat else "ukendt")]
        if shop:
            bits.append(", ".join(shop))
        bits.append("koblet i: " + (", ".join(wired) if wired else (auto_note or "ingen direkte import (findes den automatisk via en butiksliste, eller er den glemt?)")))
        if i["built"]:
            bits.append("bygger: " + key_text(i["built"], i["built"]))
        if SCRAPER_MODE:
            sfn = {x[0] for x in sf}
            oth = [n for n, _a, _ln in i.get("funcs", ()) if n not in sfn]
            if oth:
                bits.append("hjælpere: " + ", ".join(oth[:8]) + (" …" if len(oth) > 8 else ""))
            if i.get("imports"):
                bits.append("importerer: " + ", ".join(f"`{x}`" for x in sorted(i["imports"])))
        add("- " + " · ".join(bits))
    add("")

scraper_files = {f for f, _i, _sf in scrapers}
relevant = None
if SCRAPER_MODE:
    relevant = set()
    for f, i, sf in scrapers:
        relevant.add(f)
        relevant |= set(i.get("imports", ()))
        relevant |= used_by.get(f, set())
    for a in auto_by:
        relevant.add(a)
        relevant |= used_by.get(a, set())
add("## Python-filer")
for f in py_files:
    if relevant is not None and f not in relevant:
        continue
    if SCRAPER_MODE and f in scraper_files:
        continue                                  # står allerede i oversigten ovenfor
    i = infos[f]
    head = f"### `{f}` · {i['lines']} linjer"
    if not i["error"]:
        if i["has_main"]:
            head += " · entry point"
        elif i["toplevel_code"]:
            head += " · script"
    if started_by.get(f):
        head += " · startes fra " + ", ".join(f"`{s}`" for s in sorted(started_by[f]))
    add("")
    add(head)
    if i["error"]:
        add(f"- OBS: SyntaxError i linje {i['error']}")
        continue
    for _ln, _msg in i.get("warns", ())[:2]:
        add(f"- OBS: {_msg} (linje {_ln})")
    if i["doc"]:
        add(f"- {i['doc']}")
    if i["imports"] and (not SCRAPER_MODE or f in scraper_files):
        add("- **Importerer:** " + ", ".join(f"`{x}`" for x in sorted(i["imports"])))
    if used_by.get(f):
        add("- **Bruges af:** " + ", ".join(f"`{x}`" for x in sorted(used_by[f])))
    if i["ext"]:
        add("- **Eksterne:** " + ", ".join(sorted(i["ext"])))
    if i["refs"] and not KORT:
        add("- **Refererer:** " + ", ".join(f"`{x}`" for x in sorted(i["refs"])))
    if i["env"]:
        add("- **Miljøvariabler:** " + ", ".join(f"`{x}`" for x in sorted(i["env"])))
    if i["consts"]:
        c = i["consts"]
        add("- **Konstanter:** " + ", ".join(c[:12]) + (" …" if len(c) > 12 else ""))
    if i["built"] and not KORT:
        add("- **Bygger nøgler:** " + key_text(i["built"], i["built"]))
    if i["read"] and not KORT:
        add("- **Læser nøgler:** " + key_text(i["read"]))
    if i["classes"]:
        add("- **Klasser:** " + "; ".join(f"`{n}({b})` L{ln}" if b else f"`{n}` L{ln}" for n, b, ln in i["classes"]))
    if i["routes"]:
        add("- **Routes:** " + "; ".join(f"`{m} {p}` -> {fn}" for m, p, fn in i["routes"]))
    if i["funcs"]:
        add("- **Funktioner:** " + ", ".join(f"`{n}({a})` L{ln}" for n, a, ln in i["funcs"]))
add("")

# andre filer
add("## Andre filer")
refs_to = collections.defaultdict(set)
for f, i in infos.items():
    for r in i.get("refs", ()):
        refs_to[r].add(f)
for d in [""] + sorted(dirs):
    if d.count("/") >= 3 or any(d != c and d.startswith(c + "/") for c in collapsed):
        continue
    if d in collapsed:
        fl = [f for f in other_files if f.startswith(d + "/")]
        if fl:
            add(f"- `{d}/*` - {len(fl)} filer ({ext_counts(fl)})")
        continue
    fl = [f for f in by_dir.get(d, []) if not f.endswith(".py")]
    if not fl:
        continue
    if d == "":
        add(f"- `./` - {len(fl)} filer ({ext_counts(fl)})")
        for f in fl:
            if f in refs_to:
                add(f"  - `{f}` <- " + ", ".join(f"`{x}`" for x in sorted(refs_to[f])))
    else:
        add(f"- `{d}/`")
        for f in fl[:25]:
            b = os.path.basename(f)
            add(f"  - `{b}`" + (" <- " + ", ".join(f"`{x}`" for x in sorted(refs_to[b])) if b in refs_to else ""))
        if len(fl) > 25:
            add(f"  - … og {len(fl) - 25} flere")
add("")

# startscripts
add("## Startscripts")
shown_any = False
for s in sorted(script_text):
    lines = []
    for l in script_text[s].split("\n"):
        t = l.strip()
        if not t or re.match(r"(?i)^(@echo|echo|rem\b|::|pause|setlocal|timeout)", t) or t.startswith("#"):
            continue
        if s.lower().endswith(".ps1") and not re.search(r"(?i)(python|\.py\b|\bgit\s)", t):
            continue                                   # PowerShell-scripts: kun de linjer, der kører noget
        lines.append(t if len(t) <= 160 else t[:159] + "…")
    if lines:
        shown_any = True
        add(f"`{s}`")
        add("```")
        L.extend(lines[:18])
        if len(lines) > 18:
            add("…")
        add("```")
if not shown_any:
    add("(ingen .bat/.ps1-filer)")
add("")

# mistænkt ubrugte
unused = []
for f, i in infos.items():
    if i.get("error") or os.path.basename(f) == "__init__.py":
        continue
    if used_by.get(f) or i.get("has_main") or i.get("toplevel_code") or started_by.get(f):
        continue
    if any(os.path.basename(f) in (txt or "") for txt in script_text.values()):
        continue
    unused.append(f)
add("## Mistænkt ubrugte Python-filer")
add("Ingen andre filer importerer dem, de har ingen `__main__`-blok eller kode på øverste niveau og nævnes ikke i .bat/.ps1. Kan stadig være i brug (dynamisk import, kørt i hånden). Tjek før sletning.")
add("")
if unused:
    for f in unused:
        add(f"- `{f}`")
else:
    add("(ingen)")

if SCRAPER_MODE:                                      # kun noter, scrapere og de relevante filer
    cut = next((n for n, l in enumerate(L) if l == "## Andre filer"), len(L))
    L = L[:cut]
text = "\n".join(L).rstrip() + "\n"
if STDOUT:
    sys.stdout.write(text)
else:
    out_path = os.path.join(ROOT, OUT)
    with open(out_path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text.replace("\n", "\r\n") if os.name == "nt" else text)
    print(f"Skrev {OUT}: {len(text):,} tegn (ca. {len(text) // 4:,} tokens), {len(py_files)} Python-filer.")
    gi = os.path.join(ROOT, ".gitignore")
    ignored_ok = False
    if os.path.isfile(gi):
        with open(gi, encoding="utf-8", errors="replace") as fh:
            ignored_ok = any(l.strip() in (OUT, "PROJECT_*.md", "PROJECT_MAP*.md", "*.md", "/" + OUT) for l in fh)
    if not ignored_ok:
        print(f"ADVARSEL: {OUT} står ikke i .gitignore. Så kan den blive offentliggjort via GitHub Pages. Tilføj linjen {OUT} til .gitignore.")
    if not notes_path:
        print(f"Bemærk: {NOTES} blev ikke fundet, så Noter-sektionen er tom.")
    _w = [(f, ln, m) for f, i in infos.items() for ln, m in i.get("warns", ())]
    if _w:
        print("Bemærk: Python advarer om ugyldige escape-sekvenser (skriv r-streng eller dobbelt backslash) i: "
              + ", ".join(f"{f}:{ln}" for f, ln, _m in _w[:6]))
