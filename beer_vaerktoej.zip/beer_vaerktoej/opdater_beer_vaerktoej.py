#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BeerSniffer: projektkort, tjek og sikring af opdateringen.

    python opdater_beer_vaerktoej.py C:\\Kodning\\beer-sniffer --tor     tørkørsel: viser kun, hvad der sker
    python opdater_beer_vaerktoej.py C:\\Kodning\\beer-sniffer           installér

Hvad den gør:
  * lægger projectmap.py, tjek_scraper_kort.py og de nye noter (PROJECT_NOTES.md) i projektet
  * retter build_data.py på fire kontrollerede steder:
      1. stopper før ingest og push, hvis en butik er faldet mere end 30 % siden sidst (--tillad-fald tillader det)
      2. gemmer antal pr. butik i scrape_counts.json efter en vellykket kørsel
      3. BEER_NO_PUSH=1 bygger uden at pushe
      4. tager fejlliste.xlsx, theme.css og theme.js med i det ene push (så bat-filens ekstra push ikke længere
         udløser et nyt deploy, og designfilerne ikke glemmes)
  * opretter .projectmapignore og tilføjer linjer til .gitignore, hvis de mangler
  * backup af alt, der ændres, lægges UDEN FOR projektmappen: <projekt>_backup_vaerktoej_<tid>\\
  * kan køres igen uden skade
Gå tilbage: kopiér filerne fra backup-mappen tilbage.
"""
import argparse, datetime, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOL_FILES = ['projectmap.py', 'tjek_scraper_kort.py', 'PROJECT_NOTES.md']
MARK = '# BEER-VÆRKTØJ: spærre mod store fald'
MARK2 = '# BEER-VÆRKTØJ: bryggeri-udledning'

HELPERS = '''# BEER-VÆRKTØJ: spærre mod store fald (start)
COUNTS_FILE = "scrape_counts.json"
FALD_GRAENSE = 0.30      # stop, hvis en butik er faldet mere end 30 % siden sidste godkendte kørsel
FALD_MIN_FOER = 30       # kun butikker, der havde mindst så mange varer sidst


def _indlaes_tal():
    try:
        with open(COUNTS_FILE, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _find_fald(results, foer, graense=FALD_GRAENSE, minimum=FALD_MIN_FOER):
    """[(butik, før, nu)] for butikker, der er faldet mere end grænsen siden sidst."""
    fald = []
    for shop, nu in results.items():
        gammel = foer.get(shop)
        if isinstance(nu, int) and isinstance(gammel, int) and gammel >= minimum and nu < gammel * (1 - graense):
            fald.append((shop, gammel, nu))
    return fald


def _gem_tal(results):
    tal = _indlaes_tal()
    for shop, n in results.items():
        if isinstance(n, int) and n > 0:
            tal[shop] = n
    try:
        with open(COUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(tal, f, ensure_ascii=False, indent=1)
    except OSError:
        pass
# BEER-VÆRKTØJ (slut)


'''
GUARD = '''
    # BEER-VÆRKTØJ: stop før ingest og push, hvis en butik er faldet kraftigt (fx blokeret midt i en hentning)
    _fald = _find_fald(results, _indlaes_tal())
    if _fald and "--tillad-fald" not in sys.argv:
        print("\\n❌ STOP: store fald siden sidste kørsel:")
        for _s, _a, _b in _fald:
            print(f"   {_s}: {_a} → {_b} ({(_b - _a) / _a * 100:+.0f} %)")
        print("   Intet er gemt eller pushet. Prøv igen senere, eller kør med --tillad-fald, hvis faldet er reelt.")
        sys.exit(1)
'''
PUSHCTL = '''    # BEER-VÆRKTØJ: husk antal pr. butik, og lad BEER_NO_PUSH=1 bygge uden at pushe
    _gem_tal(results)
    if os.environ.get("BEER_NO_PUSH"):
        print("\\nℹ️ BEER_NO_PUSH er sat: bygget lokalt, men pusher IKKE til GitHub.")
        return
'''
HELPERS2 = '''# BEER-VÆRKTØJ: bryggeri-udledning (start)
_STIL_ORD = {"ipa", "dipa", "tipa", "neipa", "stout", "porter", "sour", "gose", "lager", "pilsner", "pils", "ale", "weisse", "weizen", "saison",
             "lambic", "gueuze", "kriek", "witbier", "hvedeøl", "øl", "beer", "brew", "brewing", "bryg", "bryghus", "brewery", "collab", "special",
             "limited", "imperial", "double", "triple", "pale", "india", "session"}


def _norm_navn(s):
    s = (s or "").replace("’", "'").replace("`", "'").replace("´", "'")
    return " ".join(s.lower().split())


def udled_bryggeri(items):
    """Fyld manglende bryggeri ud fra navnet, når det begynder med et kendt bryggeri.
    Kendt = optræder som bryggeri på mindst 2 varer og ligner ikke en stilart. Længste match vinder. Rører aldrig et udfyldt bryggeri."""
    antal = {}
    for it in items:
        b = (it.get("brewery") or "").strip()
        if b:
            antal.setdefault(_norm_navn(b), [b, 0])[1] += 1
    kendte = {k: v[0] for k, v in antal.items()
              if v[1] >= 2 and 3 <= len(k) <= 40 and not any(c.isdigit() for c in k) and k not in _STIL_ORD}
    per_foerste = {}
    for k in kendte:
        per_foerste.setdefault(k.split(" ", 1)[0], []).append(k)
    for lst in per_foerste.values():
        lst.sort(key=len, reverse=True)
    n = 0
    for it in items:
        if (it.get("brewery") or "").strip():
            continue
        navn = _norm_navn(it.get("name"))
        foerste = navn.split(" ", 1)[0] if navn else ""
        for k in per_foerste.get(foerste, ()):
            if navn.startswith(k + " ") and len(navn) > len(k) + 1:
                it["brewery"] = kendte[k]
                n += 1
                break
    return n
# BEER-VÆRKTØJ: bryggeri-udledning (slut)


'''
UDLED = '''    # BEER-VÆRKTØJ: bryggeri-udledning: udled manglende bryggeri fra navnets start (fx "Gamborg Bryghus Ein Hefeweizen").
    #   Kører FØR facitlisten, så dine egne rettelser stadig vinder.
    _udledt = udled_bryggeri(items)
    if _udledt:
        print(f"   🏭 {_udledt} manglende bryggerier udledt af navnet")

'''
A_FACIT = '    # 1b. Facitliste: anvend manuelle overrides FOER matchning (facit vinder)\n'
A_DEF = 'def run_all_scrapers():\n'
A_GUARD = '        print("   typisk kun midlertidigt), eller kør med --tillad-mangler.")\n        sys.exit(1)\n'
A_PUSH = '    print(f"\\n📤 Pusher til GitHub...")\n'
A_EXTRA = '"icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png", "logo-hero.png")'
N_EXTRA = '"icon-192.png", "icon-512.png", "icon-maskable-512.png", "apple-touch-icon.png", "logo-hero.png",\n                          "theme.css", "theme.js", "fejlliste.xlsx")'


def patch_build(t, med_bryggeri=False):
    log = []
    if MARK2 in t:
        log.append(('har', 'bryggeri-udledning er allerede i build_data.py'))
    elif med_bryggeri:
        if t.count(A_DEF) == 1 and t.count(A_FACIT) == 1:
            t = t.replace(A_DEF, HELPERS2 + A_DEF).replace(A_FACIT, UDLED + A_FACIT)
            log.append(('ret', 'bryggeri-udledning (udleder manglende bryggeri fra navnet, før facit)'))
        else:
            log.append(('MANGLER', 'bryggeri-udledning: ankrene blev ikke fundet præcis én gang'))
    if MARK in t:
        log.append(('har', 'build_data.py: fald-spærre m.m. er allerede rettet'))
        return t, log
    steps = [
        ('hjælpefunktioner (fald-spærre, tal)', A_DEF, HELPERS + A_DEF),
        ('fald-spærre efter 0-varer-tjekket', A_GUARD, A_GUARD + GUARD),
        ('BEER_NO_PUSH og gem tal før push', A_PUSH, PUSHCTL + A_PUSH),
        ('theme.css, theme.js og fejlliste.xlsx med i det ene push', A_EXTRA, N_EXTRA),
    ]
    for label, old, new in steps:
        c = t.count(old)
        if c == 1:
            t = t.replace(old, new); log.append(('ret', label))
        else:
            log.append(('MANGLER', f'{label}: fandt {c} steder, forventede 1'))
    return t, log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('projekt'); ap.add_argument('--tor', action='store_true')
    ap.add_argument('--med-bryggeri', action='store_true', help='tilføj udledning af manglende bryggeri fra varenavnet')
    a = ap.parse_args()
    proj = os.path.abspath(a.projekt)
    bd = os.path.join(proj, 'build_data.py')
    if not (os.path.isfile(bd) and os.path.isfile(os.path.join(proj, 'shops.py')) and os.path.isdir(os.path.join(proj, 'app', 'scrapers'))):
        print('FEJL: %s ligner ikke BeerSniffer-projektet (build_data.py, shops.py og app\\scrapers skal findes).' % proj); return 1
    if os.path.samefile(proj, HERE):
        print('FEJL: kør scriptet med projektmappen som argument.'); return 1
    miss = [f for f in TOOL_FILES if not os.path.isfile(os.path.join(HERE, f))]
    if miss:
        print('FEJL: pakken er ikke komplet. Mangler:', ', '.join(miss)); return 1
    pre = 'TØRKØRSEL: ' if a.tor else ''
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = proj.rstrip('\\/') + '_backup_vaerktoej_' + stamp
    print('%sProjekt: %s\n%sBackup:  %s\n' % (pre, proj, pre, backup))

    raw = open(bd, 'rb').read()
    crlf = b'\r\n' in raw
    text = raw.decode('utf-8').replace('\r\n', '\n')
    new, log = patch_build(text, a.med_bryggeri)
    for st, msg in log:
        print('%s%-8s %s' % (pre, {'ret': 'ret', 'har': 'har', 'MANGLER': 'MANGLER'}[st], msg))
    bad = [m for s, m in log if s == 'MANGLER']

    actions = []
    for f in TOOL_FILES:
        src, dst = os.path.join(HERE, f), os.path.join(proj, f)
        if f == 'PROJECT_NOTES.md' and os.path.isfile(dst) and '- [S] ' in open(dst, encoding='utf-8', errors='replace').read():
            print('%s%-8s %s (dine noter har allerede [S]-mærker: rører dem ikke)' % (pre, 'har', f))
        elif os.path.isfile(dst) and open(src, 'rb').read() == open(dst, 'rb').read():
            print('%s%-8s %s (uændret)' % (pre, 'har', f))
        else:
            print('%s%-8s %s' % (pre, 'erstat' if os.path.isfile(dst) else 'ny', f)); actions.append(('copy', f))
    ign = os.path.join(proj, '.projectmapignore')
    if not os.path.isfile(ign):
        print('%s%-8s .projectmapignore (indeholder _arkiv)' % (pre, 'ny')); actions.append(('ign', None))
    gi = os.path.join(proj, '.gitignore')
    gtxt = open(gi, encoding='utf-8-sig', errors='replace').read() if os.path.isfile(gi) else ''
    glines = {l.strip() for l in gtxt.splitlines()}
    add = [l for l in ('PROJECT_*.md', '.projectmapignore', 'scrape_counts.json') if l not in glines and not (l == 'PROJECT_*.md' and ('*.md' in glines))]
    if add:
        print('%s%-8s .gitignore: %s' % (pre, 'tilføj', ', '.join(add)))
    print()
    if not bad and new == text and not actions and not add:
        print('Alt er allerede installeret. Intet at gøre.')
        return 0
    if bad:
        print('STOP: %d rettelse(r) kunne ikke placeres (din build_data.py er ændret siden min version). Intet er skrevet.' % len(bad))
        print('      Send mig build_data.py, så retter jeg ankrene.')
        return 1
    if a.tor:
        print('Tørkørsel færdig: intet er ændret. Kør igen uden --tor for at installere.')
        return 0
    os.makedirs(backup, exist_ok=True)
    for f in TOOL_FILES + ['build_data.py', '.gitignore']:
        s = os.path.join(proj, f)
        if os.path.isfile(s):
            shutil.copy2(s, os.path.join(backup, f))
    for kind, f in actions:
        if kind == 'copy':
            shutil.copy2(os.path.join(HERE, f), os.path.join(proj, f))
        elif kind == 'ign':
            with open(ign, 'w', encoding='ascii', newline='') as fh:
                fh.write('# mapper og filer, projectmap.py springer over (en pr. linje)\r\n_arkiv\r\n')
    if new != text:
        open(bd, 'w', encoding='utf-8', newline='').write(new.replace('\n', '\r\n') if crlf else new)
    if add:
        with open(gi, 'a', encoding='ascii', newline='') as fh:
            fh.write(('\r\n' if gtxt and not gtxt.endswith('\n') else '') + '\r\n'.join(add) + '\r\n')
    print('Færdig. Backup: %s' % backup)
    print('Prøv:  python projectmap.py --scraper   og   python tjek_scraper_kort.py')
    print('Første kørsel af build_data.py gemmer antal pr. butik (scrape_counts.json); spærren virker fra og med anden kørsel.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
