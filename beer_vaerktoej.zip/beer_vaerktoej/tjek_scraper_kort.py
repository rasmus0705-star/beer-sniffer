#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tjek_scraper_kort.py -- tjekker PROJECT_MAP_scraper.md og sammenholder det med koden og rom_data.json.

    python tjek_scraper_kort.py                  tjekker PROJECT_MAP_scraper.md i projektmappen
    python tjek_scraper_kort.py --forventet "Kokkens Vinhus,Spitus,Rombo,Con Maz,Whisky.dk,Vault of Spirits,Juuls"
    python tjek_scraper_kort.py --ignorer rom_kilde,til_claude     (ud over .projectmapignore)
    python tjek_scraper_kort.py --vis "Kokkens Vinhus:volume_cl"   viser eksempler på varer fra butikken, der mangler feltet
    python tjek_scraper_kort.py --bryggeri-forslag ["ØL2GO"]       (BeerSniffer) viser, hvilke manglende bryggerier der kan udledes af navnet
Profilen vælges automatisk (BeerSniffer, hvis shops.py og app/scrapers findes; ellers RomSniffer). Tving den med --profil beer|rom.

Hvad den tjekker:
  1. at kortet er friskt og dækker alle scrapere i koden (ingen manglende eller overflødige)
  2. at hver scraper er importeret, kaldt og lagt i all_items i build_rom_data.py (og står i dump_items.py)
  3. at hver scraper bygger de nøgler, parseren kræver (name, price, shop_name, url)
  4. at rom_data.json har varer fra hver butik, og hvor godt felterne er udfyldt pr. butik
  5. om kortet er blevet for stort (tokens) og hvilke mapper med kopier, der kan springes over
Rører ingenting: læser kun. Afslutter med kode 0 (OK), 1 (advarsler) eller 2 (fejl).
"""
import ast
import collections
import json
import os
import re
import sys
import warnings

warnings.filterwarnings("ignore")

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

ROOT = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = {".git", "venv", ".venv", "env", "__pycache__", "node_modules", ".idea", ".vscode"}
MAX_TOKENS_SCRAPER = 3000     # kort lavet med --scraper
MAX_TOKENS_FULD = 8000        # fuldt kort

args = sys.argv[1:]


def opt(name, default=None):
    if name in args and args.index(name) + 1 < len(args):
        return args[args.index(name) + 1]
    return default


BEER = (opt("--profil") or ("beer" if os.path.isfile(os.path.join(ROOT, "shops.py")) and os.path.isdir(os.path.join(ROOT, "app", "scrapers")) else "rom")) == "beer"
REQUIRED = ("name", "price", "shop_name") if BEER else ("name", "price", "shop_name", "url")
FIELDS = ("brewery", "type", "abv", "volume_cl", "image") if BEER else ("brand", "volume_cl", "abv", "age", "country", "type")
MAP = opt("--kort-fil", "PROJECT_MAP_scraper.md")
BUILD = opt("--byggefil", "build_data.py" if BEER else "build_rom_data.py")
DUMP = opt("--dumpfil", "dump_items.py")
DATA = opt("--data", "data.json" if BEER else "rom_data.json")
VIS = opt("--vis")
FORSLAG = "--bryggeri-forslag" in args
FORSLAG_BUTIK = opt("--bryggeri-forslag") if (opt("--bryggeri-forslag") or "").strip() and not (opt("--bryggeri-forslag") or "").startswith("--") else None
EXPECT = [x.strip() for x in (opt("--forventet", "") or "").split(",") if x.strip()]
IGNORE = [x.strip().strip("/\\") for x in (opt("--ignorer", "") or "").split(",") if x.strip()]
try:
    with open(os.path.join(ROOT, ".projectmapignore"), encoding="utf-8-sig") as fh:
        IGNORE += [x.strip().strip("/\\") for x in fh.read().splitlines() if x.strip() and not x.strip().startswith("#")]
except OSError:
    pass

results = []          # (niveau, tekst)


def log(level, text):
    results.append((level, text))


def ignored(rel):
    return any(rel == p or rel.startswith(p + "/") for p in IGNORE)


def read(path):
    try:
        with open(os.path.join(ROOT, path), encoding="utf-8-sig", errors="replace") as fh:
            return fh.read().replace("\r\n", "\n")
    except OSError:
        return None


# ───────── find .py-filer (uden ignorerede mapper) ─────────
py_files = []
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in SKIP_DIRS]
    rel_dir = os.path.relpath(dp, ROOT).replace("\\", "/")
    rel_dir = "" if rel_dir == "." else rel_dir
    if rel_dir and ignored(rel_dir):
        dn[:] = []
        continue
    for f in fn:
        if f.endswith(".py"):
            py_files.append((rel_dir + "/" + f) if rel_dir else f)

trees = {}
for f in py_files:
    try:
        trees[f] = ast.parse(read(f) or "")
    except SyntaxError as e:
        log("FEJL", f"{f}: syntaksfejl i linje {e.lineno}; kan ikke analyseres")

# ───────── scrapere i koden ─────────
code_scrapers = {}     # funktionsnavn -> dict
for f, tree in trees.items():
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and (node.name == "scrape" or node.name.startswith("scrape_")):
            keys, shop_names = set(), set()
            for n in ast.walk(tree):
                if isinstance(n, ast.Dict):
                    for k in n.keys:
                        if isinstance(k, ast.Constant) and isinstance(k.value, str):
                            keys.add(k.value)
                    for k, v in zip(n.keys, n.values):
                        if isinstance(k, ast.Constant) and k.value == "shop_name" and isinstance(v, ast.Constant) and isinstance(v.value, str):
                            shop_names.add(v.value)
                elif isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Constant) and isinstance(n.slice.value, str) and isinstance(n.ctx, ast.Store):
                    keys.add(n.slice.value)
                elif isinstance(n, ast.Assign):
                    for t in n.targets:
                        if isinstance(t, ast.Name) and t.id == "SHOP_NAME" and isinstance(n.value, ast.Constant):
                            shop_names.add(str(n.value.value))
            code_scrapers[node.name] = {"file": f, "line": node.lineno, "keys": keys, "shops": shop_names}


if BEER:
    code_scrapers = {k: v for k, v in code_scrapers.items()
                     if v["file"].startswith("app/scrapers/") and not os.path.basename(v["file"]).startswith("_")}


def local_src(tree):
    """Kildekoden fra de projektfiler, som en fil importerer (fx en fælles Shopify-hjælper)."""
    out = ""
    for n in ast.walk(tree):
        mods = []
        if isinstance(n, ast.ImportFrom) and n.module:
            mods.append(n.module)
            mods += [n.module + "." + a.name for a in n.names]
        elif isinstance(n, ast.Import):
            mods += [a.name for a in n.names]
        for m in mods:
            for cand in (m.replace(".", "/") + ".py", m.replace(".", "/") + "/__init__.py"):
                if cand in trees:
                    out += "\n" + (read(cand) or "")
    return out


def wiring(path):
    """Hvilke scrapere importeres, kaldes og lægges i all_items i en fil."""
    tree = trees.get(path)
    out = {"imports": {}, "calls": collections.defaultdict(list), "refs": collections.defaultdict(list), "extended": set()}
    if not tree:
        return out
    alias = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom):
            for a in n.names:
                if a.name.startswith("scrape"):
                    alias[a.asname or a.name] = a.name
                    out["imports"][a.name] = n.lineno
    parents = {}
    for n in ast.walk(tree):
        for c in ast.iter_child_nodes(n):
            parents[id(c)] = n
    var_of, call_funcs = {}, set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in alias:
            out["calls"][alias[n.func.id]].append(n.lineno)
            call_funcs.add(id(n.func))
        if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Name) \
                and n.value.func.id in alias and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name):
            var_of[n.targets[0].id] = alias[n.value.func.id]
    out["registry"], out["helper"], loops, helpers = {}, {}, [], {}
    for n in ast.walk(tree):                      # hjælpefunktioner, der selv kalder en af deres parametre: run(label, fn)
        if isinstance(n, ast.FunctionDef):
            params = {a.arg for a in n.args.args + n.args.kwonlyargs}
            helpers[n.name] = any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id in params for c in ast.walk(n))
    for n in ast.walk(tree):                      # løkker, der kalder det, de løber igennem
        if isinstance(n, ast.For):
            tnames = {x.id for x in ast.walk(n.target) if isinstance(x, ast.Name)}
            calls = any(isinstance(c, ast.Call) and isinstance(c.func, ast.Name) and c.func.id in tnames for c in ast.walk(n))
            ext = any((isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr in ("extend", "append")) or isinstance(c, ast.AugAssign) for c in ast.walk(n))
            it = n.iter
            var = None
            if isinstance(it, ast.Name):
                var = it.id
            elif isinstance(it, ast.Call) and isinstance(it.func, ast.Attribute) and isinstance(it.func.value, ast.Name):
                var = it.func.value.id
            loops.append({"var": var, "iter_line": it.lineno, "line": n.lineno, "calls": calls, "extends": ext})
    for n in ast.walk(tree):                      # funktionen brugt uden at blive kaldt (liste, løkke, hjælper ...)
        if isinstance(n, ast.Name) and n.id in alias and isinstance(n.ctx, ast.Load) and id(n) not in call_funcs:
            real = alias[n.id]
            out["refs"][real].append(n.lineno)
            cont, p = None, parents.get(id(n))
            while isinstance(p, (ast.Tuple, ast.List, ast.Set, ast.Dict)):
                cont, p = p, parents.get(id(p))
            if cont is not None:
                var = None
                if isinstance(p, ast.Assign) and len(p.targets) == 1 and isinstance(p.targets[0], ast.Name):
                    var = p.targets[0].id
                hit = next((lp for lp in loops if lp["calls"] and ((var and lp["var"] == var) or lp["iter_line"] == cont.lineno)), None)
                out["registry"][real] = {"line": cont.lineno, "var": var, "loop": hit}
            elif isinstance(p, ast.Call) and isinstance(p.func, ast.Name) and helpers.get(p.func.id):
                out["helper"][real] = (p.func.id, p.lineno)
    for n in ast.walk(tree):
        arg = None
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr in ("extend", "append") and n.args:
            arg = n.args[0]
        elif isinstance(n, ast.AugAssign) and isinstance(n.op, ast.Add):
            arg = n.value
        if arg is None:
            continue
        if isinstance(arg, ast.Name) and arg.id in var_of:
            out["extended"].add(var_of[arg.id])
        elif isinstance(arg, ast.Call) and isinstance(arg.func, ast.Name) and arg.func.id in alias:
            out["extended"].add(alias[arg.func.id])
    return out


# ═════════ 1. kortet ═════════
md = read(MAP)
if md is None:
    print(f"FEJL: {MAP} findes ikke. Kør først:  python projectmap.py --scraper")
    sys.exit(2)
tokens = len(md) // 4
newest = max((os.path.getmtime(os.path.join(ROOT, f)) for f in py_files), default=0)
if os.path.getmtime(os.path.join(ROOT, MAP)) + 1 < newest:
    log("ADVARSEL", f"{MAP} er ældre end den nyeste Python-fil. Kør projectmap.py --scraper igen.")
else:
    log("OK", f"{MAP} er friskt (nyere end alle Python-filer).")

sec = re.search(r"^## Scrapere[^\n]*\n(.*?)(?=^## |\Z)", md, re.S | re.M)
map_scrapers = {}
if not sec:
    log("FEJL", "Kortet har ingen sektion '## Scrapere'. Er det genereret med --scraper?")
else:
    for line in sec.group(1).splitlines():
        if not line.startswith("- `"):
            continue
        parts = line[2:].split(" · ")
        fm = re.match(r"`([^`]+)`", parts[0])
        funcs = re.findall(r"`(scrape\w*)\(", " ".join(parts[1:2]))
        plat = next((p[len("platform: "):] for p in parts if p.startswith("platform: ")), "?")
        for fn_ in funcs:
            map_scrapers[fn_] = {"file": fm.group(1) if fm else "?", "platform": plat}
    missing = sorted(set(code_scrapers) - set(map_scrapers))
    extra = sorted(set(map_scrapers) - set(code_scrapers))
    if missing:
        log("FEJL", "Scrapere i koden, men IKKE i kortet: " + ", ".join(missing) + "  -> kør projectmap.py --scraper igen (eller tjek --ignorer).")
    if extra:
        log("ADVARSEL", "Scrapere i kortet, men ikke i koden (slettet, eller i en ignoreret mappe): " + ", ".join(extra))
    if not missing and not extra:
        log("OK", f"Kortet dækker alle {len(code_scrapers)} scrapere i koden.")
    unk = [k for k, v in map_scrapers.items() if v["platform"].startswith("ukendt")]
    if unk:
        log("INFO", "Platform ikke genkendt (normalt for butikker med egen HTML eller feed): " + ", ".join(sorted(unk)))

# ═════════ 2. koblet på ═════════
wb = wiring(BUILD)
wd = wiring(DUMP) if (DUMP in trees and not BEER) else None
if BUILD not in trees:
    log("FEJL", f"{BUILD} blev ikke fundet eller kunne ikke læses.")
if BEER:
    shopify_set = set()
    for n_ in ast.walk(trees.get(BUILD) or ast.parse("")):
        if isinstance(n_, ast.Assign) and any(isinstance(t_, ast.Name) and t_.id == "SHOPIFY" for t_ in n_.targets) \
                and isinstance(n_.value, (ast.Set, ast.List, ast.Tuple)):
            shopify_set |= {e.value for e in n_.value.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)}
    names_seen = {}
    for f_, tree_ in sorted(trees.items()):
        if not f_.startswith("app/scrapers/") or os.path.basename(f_) in ("__init__.py",) or f_.count("/") != 2:
            continue
        base_ = os.path.basename(f_)
        consts_ = {}
        for node in tree_.body:
            if isinstance(node, ast.Assign):
                for tg in node.targets:
                    if isinstance(tg, ast.Name) and tg.id.startswith("SHOP_"):
                        consts_[tg.id] = node.value
        sfuncs = [n for n in tree_.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith("scrape_")]
        if base_.startswith("_"):
            log("INFO", f"{f_}: starter med _ og springes over af butiksfinderen (ok, hvis det ikke er en scraper).")
            continue
        if not sfuncs and "SHOP_NAME" not in consts_:
            log("INFO", f"{f_}: ingen SHOP_NAME og ingen scrape_-funktion; ser ud som en hjælpefil.")
            continue
        sn = consts_.get("SHOP_NAME")
        shop = sn.value if isinstance(sn, ast.Constant) and isinstance(sn.value, str) else None
        probs, notes_ = [], []
        if sn is None:
            probs.append("mangler SHOP_NAME: butiksfinderen springer filen STILLE over")
        if not sfuncs:
            probs.append("ingen top-level def scrape_<navn>(): filen springes stille over")
        elif isinstance(sfuncs[0], ast.AsyncFunctionDef):
            probs.append("scraperen er async def, det understøttes ikke")
        if len(sfuncs) > 1:
            notes_.append(f"flere scrape_-funktioner; kun den første ({sfuncs[0].name}) bruges")
        if "SHOP_URL" not in consts_:
            notes_.append("mangler SHOP_URL")
        if "SHOP_SHIPPING" not in consts_:
            notes_.append("mangler SHOP_SHIPPING (sæt den til None, hvis butikken ikke har fragtregler)")
        if shop:
            if shop in names_seen:
                probs.append(f"SHOP_NAME '{shop}' bruges også af {names_seen[shop]}")
            names_seen[shop] = f_
        lits = set()
        for n_ in ast.walk(tree_):
            if isinstance(n_, ast.Dict):
                for k_, v_ in zip(n_.keys, n_.values):
                    if isinstance(k_, ast.Constant) and k_.value == "shop_name" and isinstance(v_, ast.Constant) and isinstance(v_.value, str):
                        lits.add(v_.value)
        if shop and lits and lits != {shop}:
            probs.append(f"returnerer shop_name {sorted(lits)}, men SHOP_NAME er '{shop}'")
        src_ = (read(f_) or "") + local_src(tree_)
        is_shopify = "products.json" in src_
        group = ""
        if shop and is_shopify:
            if shop in shopify_set:
                group = ", Shopify (køres én ad gangen)"
            else:
                probs.append(f"er en Shopify-butik, men '{shop}' står ikke i SHOPIFY-sættet i {BUILD}: den køres parallelt og kan ramme Shopifys hastighedsgrænse")
        elif shop and shop in shopify_set:
            notes_.append("står i SHOPIFY-sættet, men koden nævner ikke products.json")
        if probs:
            log("FEJL", f"{f_}: " + "; ".join(probs))
        else:
            _info = [nt for nt in notes_ if "mangler" not in nt]
            log("OK", f"{f_}: fundet som '{shop}'{group}." + (" " + "; ".join(_info) + "." if _info else ""))
        for nt in notes_:
            if "mangler" in nt:
                log("ADVARSEL", f"{f_}: {nt}.")
    allshops_ = {v for v in names_seen}
    for s_ in sorted(shopify_set - allshops_):
        log("ADVARSEL", f"SHOPIFY-sættet i {BUILD} nævner '{s_}', men ingen scraper har det SHOP_NAME (stavefejl eller slettet butik?).")
for fn_, info in ([] if BEER else sorted(code_scrapers.items())):
    name = f"{fn_} ({info['file']})"
    probs = []
    if fn_ not in wb["imports"]:
        probs.append(f"ikke importeret i {BUILD}")
    elif fn_ not in wb["calls"] and fn_ in wb["registry"] and wb["registry"][fn_]["loop"]:
        rg = wb["registry"][fn_]
        if rg["loop"]["extends"]:
            log("OK", f"{name}: importeret L{wb['imports'][fn_]}, står i scraper-listen (L{rg['line']}), kaldes i løkke (L{rg['loop']['line']}) og lægges i all_items.")
        else:
            log("ADVARSEL", f"{name}: står i scraper-listen (L{rg['line']}) og kaldes i løkke (L{rg['loop']['line']}), men jeg kan ikke se, at resultatet lægges i all_items.")
        continue
    elif fn_ not in wb["calls"] and fn_ in wb["helper"]:
        h, hl = wb["helper"][fn_]
        log("OK", f"{name}: importeret L{wb['imports'][fn_]}, sendt til hjælperen {h}() (L{hl}), som kalder den.")
        continue
    elif fn_ not in wb["calls"] and fn_ in wb["refs"]:
        ln = wb["refs"][fn_][0]
        src_lines = (read(BUILD) or "").split("\n")
        ex = " | ".join(s.strip() for s in src_lines[max(ln - 2, 0): ln + 1] if s.strip())[:230]
        log("ADVARSEL", f"{name}: bruges i {BUILD} (linje {ln}), men jeg kan ikke se, at den kaldes og lægges i all_items. Uddrag: {ex}")
        continue
    elif fn_ not in wb["calls"]:
        probs.append(f"importeret, men aldrig brugt i {BUILD} (udkommenteret?)")
    elif len(wb["calls"][fn_]) > 1:
        probs.append(f"kaldt {len(wb['calls'][fn_])} gange i {BUILD} (linje {', '.join(map(str, wb['calls'][fn_]))})")
    if fn_ in wb["calls"] and fn_ not in wb["extended"]:
        probs.append("resultatet lægges ikke i all_items (extend mangler?)")
    if probs:
        log("FEJL", f"{name}: " + "; ".join(probs))
    else:
        log("OK", f"{name}: importeret L{wb['imports'][fn_]}, kaldt L{wb['calls'][fn_][0]}, lagt i all_items.")
    if wd is not None and fn_ not in wd["imports"]:
        log("INFO", f"{name}: står ikke i {DUMP} (kun til analyse; valgfrit).")
for imp in ([] if BEER else sorted(set(wb["imports"]) - set(code_scrapers))):
    log("ADVARSEL", f"{BUILD} importerer {imp}, men den findes ikke som scraper i koden.")

# ═════════ 3. nøgler ═════════
for fn_, info in sorted(code_scrapers.items()):
    miss = [k for k in REQUIRED if k not in info["keys"]]
    if miss:
        log("ADVARSEL", f"{fn_}: kunne ikke se nøglerne {', '.join(miss)} i en dict i filen (kan være bygget i en hjælpefunktion; tjek selv).")
    else:
        log("OK", f"{fn_}: bygger alle krævede nøgler ({', '.join(REQUIRED)}).")

# ═════════ 4. data ═════════
shop_stats = {}
raw = read(DATA)
if raw is None:
    log("INFO", f"{DATA} findes ikke; springer datatjekket over (kør build_rom_data.py med ROM_NO_PUSH=1 først).")
else:
    try:
        data = json.loads(raw)
        _key = "beers" if BEER else "roms"
        roms = data[_key] if isinstance(data, dict) and _key in data else (data if isinstance(data, list) else [])
    except Exception as e:
        roms = []
        log("FEJL", f"{DATA} kunne ikke læses: {e}")
    overall = {f: sum(1 for r in roms if r.get(f) not in (None, "", 0)) for f in FIELDS}
    for r in roms:
        shops_in = {p.get("shop_name") for p in r.get("prices", [])}
        for p in r.get("prices", []):
            s = p.get("shop_name") or "?"
            st = shop_stats.setdefault(s, {"priser": 0, "roms": set(), "multi": 0, "uden_url": 0, "dårlig_pris": 0, "felter": collections.Counter()})
            st["priser"] += 1
            if id(r) not in st["roms"]:
                st["roms"].add(id(r))
                if len(shops_in) > 1:
                    st["multi"] += 1
                for f in FIELDS:
                    if r.get(f) not in (None, "", 0):
                        st["felter"][f] += 1
            if not p.get("url"):
                st["uden_url"] += 1
            try:
                if not (5 <= float(p.get("price")) <= 100000):
                    st["dårlig_pris"] += 1
            except (TypeError, ValueError):
                st["dårlig_pris"] += 1
    code_shops = {s for i in code_scrapers.values() for s in i["shops"]}
    for s in sorted(code_shops - set(shop_stats)):
        log("FEJL", f"Scraperen for '{s}' (fra koden) har ingen varer i {DATA}. Leverer den 0, eller staves butiksnavnet anderledes?")
    for s in sorted(set(shop_stats) - code_shops):
        if code_shops:
            log("INFO", f"'{s}' har varer i {DATA}, men navnet findes ikke som tekst i en scraper (navnet kan komme fra en variabel).")
    for s in EXPECT:
        if s not in shop_stats:
            log("FEJL", f"Forventet butik '{s}' mangler i {DATA}.")
    if EXPECT and all(s in shop_stats for s in EXPECT):
        log("OK", f"Alle {len(EXPECT)} forventede butikker har varer i {DATA}.")
    for s, st in sorted(shop_stats.items()):
        n = len(st["roms"]) or 1
        if st["uden_url"]:
            log("ADVARSEL", f"{s}: {st['uden_url']} priser uden url.")
        if st["dårlig_pris"]:
            log("ADVARSEL", f"{s}: {st['dårlig_pris']} priser uden for 5-100.000 kr (eller uden tal).")
        for f in FIELDS:
            shop_cov = 100 * st["felter"][f] / n
            all_cov = 100 * overall[f] / max(len(roms), 1)
            if shop_cov < all_cov - 25:
                log("ADVARSEL", f"{s}: kun {shop_cov:.0f}% af varerne har {f} (samlet {all_cov:.0f}%). Tjek scraperens parsing.")

# ═════════ 5. størrelse og kopier ═════════
blocks = [(len(b), b.split("`")[1]) for b in re.split(r"\n(?=### `)", md) if b.startswith("### `")]
scraper_mode = "## Mapper" not in md
limit = MAX_TOKENS_SCRAPER if scraper_mode else MAX_TOKENS_FULD
parts_sz = {}
for chunk in re.split(r"\n(?=## )", md):
    m_ = re.match(r"## ([^\n(]+)", chunk)
    if m_:
        parts_sz[m_.group(1).strip()] = len(chunk) // 4
dist = ", ".join(f"{k} {v:,}" for k, v in sorted(parts_sz.items(), key=lambda kv: -kv[1])[:4])
if tokens > limit:
    log("ADVARSEL", f"Kortet er ca. {tokens:,} tokens (mål: under {limit:,}). Fordeling i tokens: {dist}. Største filer: " + ", ".join(f"{n} ({sz // 4})" for sz, n in sorted(blocks, reverse=True)[:4]))
else:
    log("OK", f"Kortet er ca. {tokens:,} tokens (under {limit:,}). Fordeling i tokens: {dist}.")
root_py = {f for f in os.listdir(ROOT) if f.endswith(".py")}
dup_dirs = {}
for dp, dn, fn in os.walk(ROOT):
    dn[:] = [d for d in dn if d not in SKIP_DIRS]
    rel_dir = os.path.relpath(dp, ROOT).replace("\\", "/")
    if rel_dir == "." or ignored(rel_dir):
        continue
    dup = [f for f in fn if f.endswith(".py") and f in root_py]
    if dup:
        dup_dirs[rel_dir] = len(dup)
if dup_dirs:
    log("ADVARSEL", "Mapper med kopier af filer fra roden (fylder i kortet): " + ", ".join(f"{d} ({n})" for d, n in dup_dirs.items())
        + ". Tilføj dem til .projectmapignore.")
else:
    log("OK", "Ingen mapper med kopier af rodens Python-filer.")

# ───────── udskrift ─────────
order = {"FEJL": 0, "ADVARSEL": 1, "INFO": 2, "OK": 3}
mark = {"FEJL": "[FEJL]    ", "ADVARSEL": "[ADVARSEL]", "INFO": "[info]    ", "OK": "[ok]      "}
print(f"\nTJEK AF {MAP}   ({len(code_scrapers)} scrapere i koden, ca. {tokens:,} tokens)\n")
for level in ("FEJL", "ADVARSEL", "INFO", "OK"):
    for lv, tx in results:
        if lv == level:
            print(f"{mark[lv]} {tx}")
if shop_stats:
    print(f"\nBUTIKKER I {DATA} (felter = andel af butikkens varer med feltet)")
    short = {"brand": "brand", "volume_cl": "cl", "abv": "abv", "age": "alder", "country": "land", "type": "type", "brewery": "bryg", "image": "foto"}
    print(f"  {'butik':<17}{'priser':>6}{'samm.':>6}" + "".join(f"{short[f]:>6}" for f in FIELDS))
    for s, st in sorted(shop_stats.items(), key=lambda kv: -kv[1]["priser"]):
        n = len(st["roms"]) or 1
        print(f"  {s[:16]:<17}{st['priser']:>6}{100 * st['multi'] // n:>5}%" + "".join(f"{100 * st['felter'][f] // n:>5}%" for f in FIELDS))
    print("  (samm. = andel af butikkens varer, der også findes i mindst én anden butik)")
if VIS and raw is not None and ":" in VIS:
    vs, vf = VIS.rsplit(":", 1)
    rows = []
    for r in roms:
        for p in r.get("prices", []):
            if p.get("shop_name") == vs and r.get(vf) in (None, "", 0):
                rows.append((r.get("name", "?"), p.get("url", "")))
                break
    print(f"\nVARER FRA {vs} UDEN {vf}: {len(rows)} stk. De første 15:")
    for nm, u in rows[:15]:
        print(f"  {nm[:60]:<60} {u}")
if FORSLAG and raw is not None and BEER:
    STIL = {"ipa", "dipa", "tipa", "neipa", "stout", "porter", "sour", "gose", "lager", "pilsner", "pils", "ale", "weisse", "weizen", "saison",
            "lambic", "gueuze", "kriek", "witbier", "hvedeøl", "øl", "beer", "brew", "brewing", "bryg", "bryghus", "brewery", "collab", "special",
            "limited", "imperial", "double", "triple", "pale", "india", "session"}

    def nn(s):
        return " ".join((s or "").replace("’", "'").replace("`", "'").replace("´", "'").lower().split())
    cnt = {}
    for r in roms:
        b = (r.get("brewery") or "").strip()
        if b:
            cnt.setdefault(nn(b), [b, 0])[1] += 1
    kendte = {k: v[0] for k, v in cnt.items() if v[1] >= 2 and 3 <= len(k) <= 40 and not any(c.isdigit() for c in k) and k not in STIL}
    per = {}
    for k in kendte:
        per.setdefault(k.split(" ", 1)[0], []).append(k)
    for lst in per.values():
        lst.sort(key=len, reverse=True)
    print(f"\nBRYGGERI-FORSLAG (kun visning, intet ændres). Kendte bryggerier (mindst 2 varer): {len(kendte)}")
    print(f"  {'butik':<17}{'mangler':>8}{'kan udledes':>12}{'andel':>7}")
    ex = collections.defaultdict(list)
    tot = collections.Counter(); hit = collections.Counter()
    for r in roms:
        if (r.get("brewery") or "").strip():
            continue
        nm = nn(r.get("name")); fst = nm.split(" ", 1)[0] if nm else ""
        sug = next((k for k in per.get(fst, ()) if nm.startswith(k + " ") and len(nm) > len(k) + 1), None)
        for s in {p.get("shop_name") for p in r.get("prices", [])}:
            tot[s] += 1
            if sug:
                hit[s] += 1
                if len(ex[s]) < 14:
                    ex[s].append((r.get("name", "?"), kendte[sug]))
    for s, n_ in sorted(tot.items(), key=lambda kv: -kv[1]):
        print(f"  {s[:16]:<17}{n_:>8}{hit[s]:>12}{100 * hit[s] // max(n_, 1):>6}%")
    for s in ([FORSLAG_BUTIK] if FORSLAG_BUTIK else [x for x, _ in sorted(hit.items(), key=lambda kv: -kv[1])[:1]]):
        print(f"\n  Eksempler fra {s} (varenavn  ->  udledt bryggeri):")
        for nm_, br in ex.get(s, []):
            print(f"    {nm_[:52]:<52} -> {br}")
fails = sum(1 for lv, _ in results if lv == "FEJL")
warns = sum(1 for lv, _ in results if lv == "ADVARSEL")
print(f"\nRESULTAT: {fails} fejl, {warns} advarsler." + ("  Alt ser rigtigt ud." if not fails and not warns else ""))
sys.exit(2 if fails else (1 if warns else 0))
