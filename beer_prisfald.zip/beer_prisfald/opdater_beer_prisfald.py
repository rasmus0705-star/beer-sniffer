#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BeerSniffer: privat prisfald-side (prisfald.html).

    python opdater_beer_prisfald.py C:\\Kodning\\beer-sniffer --tor     tørkørsel: viser kun, hvad der sker
    python opdater_beer_prisfald.py C:\\Kodning\\beer-sniffer           installér

Hvad den gør:
  * lægger prisfald.py i projektet
  * gemmer de nuværende priser (data.json) som første kørsel, så siden viser prisfald allerede efter næste opdatering
  * retter build_data.py to steder: bygger prisfald.html efter hver kørsel (gemmer kun tilstanden ved en rigtig kørsel,
    ikke når BEER_NO_PUSH er sat), og tager prisfald.html med i det ene push
  * tilføjer prisfald_state.json og prisfald.py til .gitignore
  * backup uden for projektmappen: <projekt>_backup_prisfald_<tid>\\ ; kan køres igen uden skade
Kræver, at opdater_beer_vaerktoej.py er kørt først (build_data.py skal have fald-spærren m.m.).
Gå tilbage: kopiér build_data.py fra backup-mappen, og slet prisfald.py og prisfald.html.
"""
import argparse, datetime, importlib.util, os, shutil, sys

HERE = os.path.dirname(os.path.abspath(__file__))
MARK = '# BEER-VÆRKTØJ: prisfald-side'
A_PUSHCTL = '    # BEER-VÆRKTØJ: husk antal pr. butik, og lad BEER_NO_PUSH=1 bygge uden at pushe\n'
BLOCK = '''    # BEER-VÆRKTØJ: prisfald-side: bygger prisfald.html (privat, ikke linket fra sitet).
    #   Tilstanden (priser fra de forrige kørsler) gemmes kun ved en rigtig kørsel, ikke når BEER_NO_PUSH er sat.
    try:
        import prisfald
        _pf = prisfald.byg("data.json", gem_tilstand=not os.environ.get("BEER_NO_PUSH"))
        print(f"   📉 prisfald.html: {_pf['sidste']} fald siden sidste kørsel, {_pf['igaar']} siden i går")
    except Exception as _e:
        print(f"   ⚠️ prisfald.html kunne ikke bygges: {_e}")

'''
A_EXTRA = '"theme.css", "theme.js", "fejlliste.xlsx")'
N_EXTRA = '"theme.css", "theme.js", "fejlliste.xlsx", "prisfald.html")'


def patch_build(t):
    if MARK in t:
        return t, [('har', 'build_data.py bygger allerede prisfald-siden')]
    log = []
    if t.count(A_PUSHCTL) != 1:
        return t, [('MANGLER', 'ankeret fra opdater_beer_vaerktoej.py blev ikke fundet: kør først det script')]
    t = t.replace(A_PUSHCTL, BLOCK + A_PUSHCTL); log.append(('ret', 'byg prisfald.html efter hver kørsel'))
    if t.count(A_EXTRA) == 1:
        t = t.replace(A_EXTRA, N_EXTRA); log.append(('ret', 'prisfald.html med i det ene push'))
    else:
        log.append(('MANGLER', 'tuplen med theme.css/theme.js/fejlliste.xlsx blev ikke fundet præcis én gang'))
    return t, log


def load_module(path):
    spec = importlib.util.spec_from_file_location('prisfald_inst', path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    return m


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('projekt'); ap.add_argument('--tor', action='store_true')
    a = ap.parse_args(); proj = os.path.abspath(a.projekt); bd = os.path.join(proj, 'build_data.py')
    if not (os.path.isfile(bd) and os.path.isfile(os.path.join(proj, 'shops.py')) and os.path.isdir(os.path.join(proj, 'app', 'scrapers'))):
        print('FEJL: %s ligner ikke BeerSniffer-projektet.' % proj); return 1
    if os.path.samefile(proj, HERE):
        print('FEJL: kør scriptet med projektmappen som argument.'); return 1
    pre = 'TØRKØRSEL: ' if a.tor else ''
    stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S'); backup = proj.rstrip('\\/') + '_backup_prisfald_' + stamp
    print('%sProjekt: %s\n%sBackup:  %s\n' % (pre, proj, pre, backup))
    raw = open(bd, 'rb').read(); crlf = b'\r\n' in raw; text = raw.decode('utf-8').replace('\r\n', '\n')
    new, log = patch_build(text)
    for st, msg in log:
        print('%s%-8s %s' % (pre, st, msg))
    bad = [m for s, m in log if s == 'MANGLER']
    src, dst = os.path.join(HERE, 'prisfald.py'), os.path.join(proj, 'prisfald.py')
    same = os.path.isfile(dst) and open(src, 'rb').read() == open(dst, 'rb').read()
    print('%s%-8s prisfald.py%s' % (pre, 'har' if same else ('erstat' if os.path.isfile(dst) else 'ny'), ' (uændret)' if same else ''))
    state = os.path.join(proj, 'prisfald_state.json'); data = os.path.join(proj, 'data.json')
    seed = os.path.isfile(data) and not os.path.isfile(state)
    if seed:
        print('%s%-8s prisfald_state.json (nuværende priser fra data.json som første kørsel)' % (pre, 'ny'))
    elif os.path.isfile(state):
        print('%s%-8s prisfald_state.json findes allerede (røres ikke)' % (pre, 'har'))
    elif not os.path.isfile(data):
        print('%sADVARSEL data.json findes ikke endnu: første kørsel gemmer udgangspunktet, og prisfald vises fra anden kørsel' % pre)
    gi = os.path.join(proj, '.gitignore')
    gtxt = open(gi, encoding='utf-8-sig', errors='replace').read() if os.path.isfile(gi) else ''
    glines = {l.strip() for l in gtxt.splitlines()}
    add = [l for l in ('prisfald_state.json', 'prisfald.py') if l not in glines]
    if add:
        print('%s%-8s .gitignore: %s' % (pre, 'tilføj', ', '.join(add)))
    print()
    if bad:
        print('STOP: %d rettelse(r) kunne ikke placeres. Intet er skrevet.' % len(bad)); return 1
    if not seed and same and new == text and not add:
        print('Alt er allerede installeret. Intet at gøre.'); return 0
    if a.tor:
        print('Tørkørsel færdig: intet er ændret. Kør igen uden --tor for at installere.'); return 0
    os.makedirs(backup, exist_ok=True)
    for f in ('build_data.py', 'prisfald.py', '.gitignore', 'prisfald_state.json'):
        s = os.path.join(proj, f)
        if os.path.isfile(s):
            shutil.copy2(s, os.path.join(backup, f))
    if not same:
        shutil.copy2(src, dst)
    if new != text:
        open(bd, 'w', encoding='utf-8', newline='').write(new.replace('\n', '\r\n') if crlf else new)
    if add:
        with open(gi, 'a', encoding='ascii', newline='') as fh:
            fh.write(('\r\n' if gtxt and not gtxt.endswith('\n') else '') + '\r\n'.join(add) + '\r\n')
    if seed:
        m = load_module(dst)
        os.chdir(proj)
        m.saa('data.json', 'prisfald_state.json')
        m.byg('data.json', 'prisfald_state.json', 'prisfald.html', gem_tilstand=False)
    print('Færdig. Backup: %s' % backup)
    print('prisfald.html er bygget; den viser ingen fald endnu (den sammenligner med de samme priser). Efter næste opdatering ser du prisfaldene.')
    print('Åbn den lokalt ved at dobbeltklikke på prisfald.html. På nettet: https://beersniffer.dk/prisfald.html (ikke linket fra sitet).')
    return 0


if __name__ == '__main__':
    sys.exit(main())
